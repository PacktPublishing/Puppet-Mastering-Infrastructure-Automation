Facter.add(:hello) do
  setcode { "Hello, world!" }
end
