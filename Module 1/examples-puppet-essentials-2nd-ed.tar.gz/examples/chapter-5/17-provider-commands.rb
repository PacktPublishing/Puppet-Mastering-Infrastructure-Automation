Puppet::Type.type(:cacti_device).provide(:cli, :parent => Puppet::Provider) do
  commands :php        => 'php'
  commands :add_device => '/usr/share/cacti/cli/add_device.php'
  commands :add_graphs => '/usr/share/cacti/cli/add_graphs.php'
  commands :rm_device  => '/usr/share/cacti/cli/remove_device.php'
end
