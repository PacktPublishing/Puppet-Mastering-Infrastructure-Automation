2: Organizing your nodes and data
==============================

