defaultfor :operatingsystem => [:fedora, :centos, :redhat]
