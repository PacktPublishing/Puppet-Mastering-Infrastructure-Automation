6: Custom Types
