8: Exported Resources
