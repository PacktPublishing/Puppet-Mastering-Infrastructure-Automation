confine :operatingsystem => [:suse, :sles, :sled, :opensuse]
