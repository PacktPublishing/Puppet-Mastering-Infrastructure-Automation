5: Custom Facts and Modules
