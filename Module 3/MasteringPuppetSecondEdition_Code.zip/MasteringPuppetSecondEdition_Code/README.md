advpup
======

Mastering Puppet Second Edition
ISBN 13 : 978-1-78588-810-6

These are the files from the book. To purchase the book, visit: https://www.packtpub.com/networking-and-servers/mastering-puppet-second-edition