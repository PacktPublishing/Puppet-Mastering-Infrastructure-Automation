3: Git and Environments
=======================
