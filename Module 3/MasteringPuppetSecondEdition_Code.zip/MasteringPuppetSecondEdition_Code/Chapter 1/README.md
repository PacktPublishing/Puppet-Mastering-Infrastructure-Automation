1: Dealing with Load/Scale
========================== 
